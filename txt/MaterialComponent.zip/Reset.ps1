﻿
$RunHostName = 's75mp213'
$RunHostUser = 'AD\eds_server1'
$RunHostPass = 'pass_s75mp213'

$TestHostName = 's75mp180'
$TestHostUser = 'Administrator'
$TestHostPass = 'pass_s75mp180'


net use \\$RunHostName $RunHostPass /User:$RunHostUser

net use \\$RunHostName /delete



net use \\$TestHostName $TestHostPass /User:$TestHostUser


## s75mp180
Remove-Item -Path \\$TestHostName\F$\Task_Imp_Rcv -Force

Remove-Item -Path \\$TestHostName\F$\GetBatchDmp.bat -Force
Remove-Item -Path \\$TestHostName\F$\GetOrclFile.bat -Force

Remove-Item -Path \\$TestHostName\F$\Rcv\Eds_Auto_bat\Rvc_DB.bat -Force
Remove-Item -Path \\$TestHostName\F$\Rcv\Eds_Eng\Rvc_DB_Eng.bat -Force
Remove-Item -Path \\$TestHostName\F$\Rcv\Setubi1\Rvc_DB_Setubi1.bat -Force
Remove-Item -Path \\$TestHostName\F$\Rcv\Setubi2\Rvc_DB_Setubi2.bat -Force

net use \\$TestHostName /delete